import { Component, Output,EventEmitter } from '@angular/core';
import type{ Investments } from '../investment-input-modal';
import { investmentservice } from '../investment.service';


@Component({
  selector: 'app-user-input',
  templateUrl: './user-input.component.html',
  styleUrl: './user-input.component.scss'
})
export class UserInputComponent {
  constructor(private investmentService:investmentservice){

  }
  @Output() calculate=new EventEmitter<Investments>();
  enteredInitialInvest='0';
  enteredAnnualInvest='0';
  enteredExpectedReturn='5';
  enteredDuration='10';
  onSubmit(){
    this.investmentService.calculateInvestmentResults({
      initialInvestment :+this.enteredInitialInvest,
      duration: +this.enteredDuration,
      expectedReturn: +this.enteredExpectedReturn,
      annualInvestment: +this.enteredAnnualInvest,
    });
    this.enteredAnnualInvest =('0');
    this.enteredDuration  =('0');
    this.enteredExpectedReturn =('0');
    this.enteredInitialInvest=('0');
  }
}
