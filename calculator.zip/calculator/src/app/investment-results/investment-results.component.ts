import { Component, computed, inject, Input } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { investmentservice } from '../investment.service';

@Component({
  selector: 'app-investment-results',
  templateUrl: './investment-results.component.html',
  styleUrl: './investment-results.component.scss'
})
export class InvestmentResultsComponent {
private investmentServices=inject(investmentservice);
 results = computed(()=>this.investmentServices.outResults());

}
