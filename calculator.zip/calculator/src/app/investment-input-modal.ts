export interface Investments{
    initialInvestment:number;
    duration:number;
    expectedReturn:number;
    annualInvestment:number;
}